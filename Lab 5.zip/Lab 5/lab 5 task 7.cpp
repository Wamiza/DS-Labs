#include <iostream>
using namespace std;

#define N 5

int maze[N][N] = {
    {1,0,1,0,1},
    {1,1,1,1,1},
    {0,0,0,1,0},
    {1,1,1,1,1},
    {1,0,1,0,1}
};

int sol[N][N] = {0};

int row[4] = {-1,0,1,0};
int col[4] = {0,1,0,-1};

bool isSafe(int x, int y) {
    return (x>=0 && x<N && y>=0 && y<N && maze[x][y]==1 && sol[x][y]==0);
}

bool solveMaze(int x, int y) {
    if(x==N-1 && y==N-1) { // reached destination
        sol[x][y]=1;
        return true;
    }

    if(isSafe(x,y)) {
        sol[x][y]=1; // mark visited

        for(int k=0;k<4;k++) {
            int nx = x+row[k];
            int ny = y+col[k];
            if(solveMaze(nx,ny))
                return true;
        }

        sol[x][y]=0; // backtrack
    }
    return false;
}

int main() {
    if(solveMaze(0,0)) {
        cout<<"Solution Path:"<<endl;
        for(int i=0;i<N;i++) {
            for(int j=0;j<N;j++) {
                cout<<sol[i][j]<<" ";
            }
            cout<<endl;
        }
    }
    else
        cout<<"No Path Found"<<endl;

    return 0;
}