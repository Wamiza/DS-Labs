#include <iostream>
using namespace std;

#define N 4

int row[4] = {-1, 0, 1, 0};
int col[4] = {0, 1, 0, -1};

void printSolution(int sol[N][N]) {
    cout << "Path Found!" << endl;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout << sol[i][j] << " ";
        }
        cout << endl;
    }
}

bool isSafe(int maze[N][N], int x, int y, int sol[N][N]) {
    return (x >= 0 && x < N && y >= 0 && y < N &&
            maze[x][y] == 1 && sol[x][y] == 0);
}

bool solve(int maze[N][N], int x, int y, int sol[N][N], int tx, int ty) {
    if (x == tx && y == ty) {
        sol[x][y] = 1;
        return true;
    }
    for (int dir = 0; dir < 4; dir++) {
        int nx = x + row[dir];
        int ny = y + col[dir];
        if (isSafe(maze, nx, ny, sol)) {
            sol[nx][ny] = 1;
            if (solve(maze, nx, ny, sol, tx, ty))
                return true;
            sol[nx][ny] = 0;
        }
    }
    return false;
}

void solveMaze(int maze[N][N], int sx, int sy, int tx, int ty) {
    int sol[N][N] = {0};
    sol[sx][sy] = 1;
    if (!solve(maze, sx, sy, sol, tx, ty)) {
        cout << "No Path Found!" << endl;
    } else {
        printSolution(sol);
    }
}

int main() {
    int maze[N][N] = {
        {1, 1, 1, 1},
        {0, 0, 0, 1},
        {1, 1, 0, 1},
        {1, 1, 1, 1}
    };
    int startx = 0, starty = 0;
    int targetx = 2, targety = 0;
    solveMaze(maze, startx, starty, targetx, targety);
    return 0;
}