#include <iostream>
using namespace std;

struct Node{
	int data;
	Node* next;
	Node* prev;
	Node(int val) {
		data = val;
		next = NULL;
		prev = NULL;
	}
};

class DLL{
	private:
	Node* head;
	Node* tail;
	
	public:
	DLL(){
		head = NULL;
		tail = NULL;
	}
	
	void insertAnywhere(int pos, int val){
		Node* newNode = new Node(val);
		if(pos == 0){
			newNode->next = head;
			if(head != NULL){
				head->prev = newNode;
			}
			head = newNode;
			if(tail == NULL){
				tail = newNode;
			}
			return;
		}
		Node* temp = head;
		int i = 0;
		while(temp != NULL && i < pos - 1){
			temp = temp->next;
			i++;
		}
		if(temp == NULL){
			if(tail != NULL){
				tail->next = newNode;
				newNode->prev = tail;
				tail = newNode;
			} else {
				head = tail = newNode;
			}
			return;
		}
		newNode->next = temp->next;
		newNode->prev = temp;
		if(temp->next != NULL){
			temp->next->prev = newNode;
		}
		temp->next = newNode;
		if(newNode->next == NULL){
			tail = newNode;
		}
	}
	
	void deleteAnywhere(int pos){
		if(head == NULL){
			return;
		}
		if(pos == 0){
			Node* toDelete = head;
			head = head->next;
			if(head != NULL){
				head->prev = NULL;
			} else {
				tail = NULL;
			}
			delete toDelete;
			return;
		}
		Node* temp = head;
		int i = 0;
		while(temp != NULL && i < pos){
			temp = temp->next;
			i++;
		}
		if(temp == NULL){
			return;
		}
		if(temp->prev != NULL){
			temp->prev->next = temp->next;
		}
		if(temp->next != NULL){
			temp->next->prev = temp->prev;
		}
		if(temp == tail){
			tail = temp->prev;
		}
		delete temp;
	}
	
	void display(){
		Node* temp = head;
		while(temp != NULL){
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
	}
};

int main(){
	DLL d;
	d.insertAnywhere(0,1);
	d.insertAnywhere(1,3);
	d.insertAnywhere(2,2);
	d.display();
	d.deleteAnywhere(1);
	d.display();
	return 0;
}