#include <iostream>
using namespace std;

class Student {
    int roll;
    string name;
public:
    Student(int roll, string name){
        this->roll = roll;
        this->name = name;
    }
    void display(){
        cout<< roll << ", " << name << endl;
    }
};

struct Node {
    Student std;
    Node* next;
    Node(Student s) : std(s), next(NULL) {}   
};

class LinkedList {
    Node* head;
    Node* tail;
public:
    LinkedList() {
        head = NULL;
        tail = NULL;
    }
    void add_node_at_end(Student std) {
        Node* newnode = new Node(std);
        if (head == NULL) {
            head = newnode;
            tail = newnode;
        } else {
            tail->next = newnode;   
            tail = newnode;
        }
    }
    void display() {
        Node* temp = head;
        while (temp != NULL) {
            temp->std.display();
            cout << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList list;
    list.add_node_at_end(Student(60, "Tehreen"));
    list.add_node_at_end(Student(70, "Zara"));
    list.add_node_at_end(Student(92, "Alaya"));
    list.add_node_at_end(Student(46, "Amal"));

    cout << "Displaying the students list: " << endl;
    list.display();

    return 0;
}