#include <iostream>
using namespace std;

int recursiveArraySum(void* arr, int sizes[], int dim) {
    if (dim == 1) {
        int* base = (int*)arr;
        int sum = 0;
        for (int i = 0; i < sizes[0]; i++)
            sum += base[i];
        return sum;
    }
    int** next = (int**)arr;
    int sum = 0;
    for (int i = 0; i < sizes[0]; i++)
        sum += recursiveArraySum(next[i], sizes + 1, dim - 1);
    return sum;
}

int main() {
    int a1[] = {1, 2, 3};
    int a2[] = {4, 5};
    int* arr1[] = {a1, a2};

    int sizes[] = {2, 3};
    cout << "Sum = " << recursiveArraySum(arr1, sizes, 2) << endl;
    return 0;
}