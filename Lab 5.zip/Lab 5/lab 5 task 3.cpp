#include <iostream>
#include <cstdlib>
using namespace std;

void guess(int rn, int t){
    if(t==0){
        cout<<"You run out of chances, The actual number was: "<<rn<<endl;
    }
    int an;
    cout<<"Enter your Guess b/w 1-100, you have "<<t<<" number of chances"<<endl;
    cin>>an;

    if(rn==an){
        cout<<"You Guessed it Correct, The number was: "<<rn<<endl;
        return;
    }
    else if (an > rn) {
        cout << "Too high! Try again." << endl;
    } 
    else {
        cout << "Too low! Try again." << endl;
    }

    return guess(rn, t-1);
}

int main(){
    int t = 5;
    srand(time(0));
    int ran = rand() % 100+1;

    guess( ran, t);

    return 0;
}