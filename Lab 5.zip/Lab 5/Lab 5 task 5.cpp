#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = NULL;
    }
};

int search(int value, Node* head) {
    if(head == NULL){
    return false;
    }

    if(head->data == value){
        return true;
    }
    return search(value, head->next);
}

int main() {
    Node* head = new Node(10);
    head->next = new Node(20);
    head->next->next = new Node(30);
    head->next->next->next = new Node(40);

    int val = 30;
    val = 50;
    if (search(val, head))
        cout << val << " found in the list" << endl;
    else
        cout << val << " not found in the list" << endl;
    return 0;
}