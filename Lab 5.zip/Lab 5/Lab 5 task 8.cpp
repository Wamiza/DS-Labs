#include <iostream>
using namespace std;

#define N 4

int board[N][N] = {0};
int maxFlags = 0;
int solution[N][N] = {0};

bool isSafe(int row, int col) {
    for (int i = 0; i < row; i++)
        if (board[i][col]) return false;
    for (int i = row-1, j = col-1; i>=0 && j>=0; i--, j--)
        if (board[i][j]) return false;
    for (int i = row-1, j = col+1; i>=0 && j<N; i--, j++)
        if (board[i][j]) return false;
    return true;
}

void solve(int row, int placed) {
    if (row == N) {
        if (placed > maxFlags) {
            maxFlags = placed;
            for (int i=0; i<N; i++)
                for (int j=0; j<N; j++)
                    solution[i][j] = board[i][j];
        }
        return;
    }
    for (int col=0; col<N; col++) {
        if (isSafe(row, col)) {
            board[row][col] = 1;
            solve(row+1, placed+1);
            board[row][col] = 0;
        }
    }
    solve(row+1, placed);
}

int main() {
    solve(0,0);
    cout << "Maximum number of flags that can be placed: " << maxFlags << endl;
    cout << "One possible arrangement:" << endl;
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            cout << solution[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}