#include <iostream>
using namespace std;

int main() {
    int departments;
    cout << "Enter number of departments: " << endl;
    cin >> departments;

    int *students = new int[departments];
    int ***marks = new int**[departments];

    for (int d = 0; d < departments; d++) {
        cout << endl << "Enter number of students in Department " << d + 1 << ": " << endl;
        cin >> students[d];

        marks[d] = new int*[students[d]];
        for (int s = 0; s < students[d]; s++) {
            marks[d][s] = new int[5];
            cout << "  Enter marks of Student " << s + 1 << " (5 subjects): " << endl;
            for (int sub = 0; sub < 5; sub++) {
                cin >> marks[d][s][sub];
            }
        }
    }

    cout << endl << "<===== Department Results =====>" << endl;
    for (int d = 0; d < departments; d++) {
        int total = 0, count = 0;
        int highest = -1, lowest = 101;

        for (int s = 0; s < students[d]; s++) {
            for (int sub = 0; sub < 5; sub++) {
                int mark = marks[d][s][sub];
                total += mark;
                count++;
                if (mark > highest) highest = mark;
                if (mark < lowest) lowest = mark;
            }
        }

        double avg = (double)total / count;
        cout << endl << "Department " << d + 1 << ":" << endl;
        cout << "  Highest Marks: " << highest << endl;
        cout << "  Lowest Marks: " << lowest << endl;
        cout << "  Average Marks: " << avg << endl;
    }

    for (int d = 0; d < departments; d++) {
        for (int s = 0; s < students[d]; s++) {
            delete[] marks[d][s];
        }
        delete[] marks[d];
    }
    delete[] marks;
    delete[] students;

    return 0;
}