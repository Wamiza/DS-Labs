#include <iostream>
using namespace std;

class DynamicMatrix {
public:
    int **matrix;
    int n, m;

    DynamicMatrix(int rows, int cols) {
        n = rows;
        m = cols;
        matrix = new int*[n];
        for (int i = 0; i < n; i++) {
            matrix[i] = new int[m];
        }
    }

    void inputMatrix() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                cin >> matrix[i][j];
            }
        }
    }

    void printMatrix() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                cout << matrix[i][j] << " ";
            }
            cout << endl;
        }
    }

    void addTwoToOddIndices() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if ((i + j) % 2 != 0) {
                    matrix[i][j] += 2;
                }
            }
        }
    }

    void transpose() {
        int **newMatrix = new int*[m];
        for (int i = 0; i < m; i++) {
            newMatrix[i] = new int[n];
            for (int j = 0; j < n; j++) {
                newMatrix[i][j] = matrix[j][i];
            }
        }
        for (int i = 0; i < n; i++) {
            delete[] matrix[i];
        }
        delete[] matrix;
        int temp = n;
        n = m;
        m = temp;
        matrix = newMatrix;
    }

    void resize(int newN, int newM, int initVal = 0) {
        int **newMatrix = new int*[newN];
        for (int i = 0; i < newN; i++) {
            newMatrix[i] = new int[newM];
            for (int j = 0; j < newM; j++) {
                if (i < n && j < m) {
                    newMatrix[i][j] = matrix[i][j];
                } else {
                    newMatrix[i][j] = initVal;
                }
            }
        }
        for (int i = 0; i < n; i++) {
            delete[] matrix[i];
        }
        delete[] matrix;
        n = newN;
        m = newM;
        matrix = newMatrix;
    }

    ~DynamicMatrix() {
        for (int i = 0; i < n; i++) {
            delete[] matrix[i];
        }
        delete[] matrix;
    }
};

int main() {
    int n, m;
    cout << "Enter number of rows: " << endl;
    cin >> n;
    cout << "Enter number of columns: " << endl;
    cin >> m;

    DynamicMatrix mat(n, m);

    mat.inputMatrix();

    cout << "Original Matrix:" << endl;
    mat.printMatrix();

    mat.addTwoToOddIndices();
    cout << "After adding 2 to odd indices:" << endl;
    mat.printMatrix();

    mat.transpose();
    cout << "After Transpose:" << endl;
    mat.printMatrix();

    mat.resize(n + 1, m + 2, -1);
    cout << "After Resizing (new elements = -1):" << endl;
    mat.printMatrix();

    return 0;
}