#include <iostream>
using namespace std;

bool hasCommonFriend(bool friends[5][5], int a, int b) {
    for (int k = 0; k < 5; k++) {
        if (friends[a][k] && friends[b][k]) {
            return true;
        }
    }
    return false;
}

int main() {
    bool friends[5][5] = {
        {true,  true,  true,  false, false},
        {true,  true,  true,  false, false},
        {true,  true,  false, false, false},
        {false, false, false, true,  true },
        {false, false, false, true,  true }
    };

    int p1, p2;
    cout << "Enter two people (0-4) to check for common friend: " << endl;
    cin >> p1 >> p2;

    if (hasCommonFriend(friends, p1, p2)) {
        cout << "Yes, person " << p1 << " and person " << p2 << " have a common friend." << endl;
    } else {
        cout << "No, person " << p1 << " and person " << p2 << " do not have a common friend." << endl;
    }

    return 0;
}
