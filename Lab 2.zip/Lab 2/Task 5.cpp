#include <iostream>
using namespace std;

int main() {
    int departments = 4;
    string names[] = {"Software Engineering", "Artificial Intelligence", "Computer Science", "Data Science"};
    int coursesCount[] = {3, 4, 2, 1};

    double **gpa = new double*[departments];
    for (int i = 0; i < departments; i++) {
        gpa[i] = new double[coursesCount[i]];
    }

    for (int i = 0; i < departments; i++) {
        cout << "Enter GPA for " << coursesCount[i] << " core courses of " << names[i] << ":" << endl;
        for (int j = 0; j < coursesCount[i]; j++) {
            cin >> gpa[i][j];
        }
    }

    cout << endl << "<===== GPA of Core Courses by Department =====>" << endl;
    for (int i = 0; i < departments; i++) {
        cout << names[i] << ": ";
        for (int j = 0; j < coursesCount[i]; j++) {
            cout << gpa[i][j] << " ";
        }
        cout << endl;
    }

    for (int i = 0; i < departments; i++) {
        delete[] gpa[i];
    }
    delete[] gpa;
    return 0;
}