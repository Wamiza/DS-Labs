#include <iostream>
#include <string>
using namespace std;

int linearSearch(string arr[], int n, string target, int &steps) {
    steps=0;
    for(int i=0;i<n;i++) {
        steps++;
        if(arr[i]==target) return i;
    }
    return -1;
}

int binarySearch(string arr[], int n, string target, int &steps) {
    int left=0,right=n-1;
    steps=0;
    while(left<=right) {
        steps++;
        int mid=(left+right)/2;
        if(arr[mid]==target) return mid;
        else if(arr[mid]<target) left=mid+1;
        else right=mid-1;
    }
    return -1;
}

int main() {
    string arr[10]={"Ahmed","Ali","Basit","Karim","Rizwan","Sarwar","Tariq","Taufiq","Yasin","Zulfiqar"};
    int n=10;

    string targets[3]={"Aftab","Rizwan","Tariq"};

    for(int i=0;i<3;i++) {
        int stepsLinear,stepsBinary;
        int indexLinear=linearSearch(arr,n,targets[i],stepsLinear);
        int indexBinary=binarySearch(arr,n,targets[i],stepsBinary);

        cout<<"Searching for "<<targets[i]<<endl;
        cout<<"Linear Search -> Index: "<<indexLinear<<" Steps: "<<stepsLinear<<endl;
        cout<<"Binary Search -> Index: "<<indexBinary<<" Steps: "<<stepsBinary<<endl;

        if(stepsLinear>stepsBinary) cout<<"Binary Search faster"<<endl;
        else if(stepsLinear<stepsBinary) cout<<"Linear Search faster"<<endl;
        else cout<<"Both took same steps"<<endl;
        cout<<endl;
    }
    return 0;
}
