#include <iostream>
using namespace std;

void sortYears(int arr[], int n) {
    int c2022=0,c2023=0,c2024=0;
    for(int i=0;i<n;i++) {
        if(arr[i]==2022) c2022++;
        else if(arr[i]==2023) c2023++;
        else if(arr[i]==2024) c2024++;
    }
    int index=0;
    for(int i=0;i<c2022;i++) arr[index++]=2022;
    for(int i=0;i<c2023;i++) arr[index++]=2023;
    for(int i=0;i<c2024;i++) arr[index++]=2024;
}

int main() {
    int arr[6]={2022,2023,2024,2022,2023,2024};
    sortYears(arr,6);
    cout<<"Sorted array: ";
    for(int i=0;i<6;i++) cout<<arr[i]<<" ";
    return 0;
}
