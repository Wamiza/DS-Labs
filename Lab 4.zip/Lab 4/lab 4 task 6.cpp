#include <iostream>
using namespace std;

int binarySearch(int arr[], int n, int target) {
    int left=0,right=n-1;
    while(left<=right) {
        int mid=(left+right)/2;
        if(arr[mid]==target) return mid;
        else if(arr[mid]<target) left=mid+1;
        else right=mid-1;
    }
    return -1;
}

int main() {
    int arr[10]={5,10,15,20,25,30,35,40,45,50};
    int n=10;
    int rollDigits=18;
    bool found=false;
    for(int i=0;i<n;i++) {
        if(arr[i]==rollDigits) {
            found=true;
            break;
        }
    }
    if(!found) {
        arr[n-1]=rollDigits;
        for(int i=0;i<n-1;i++) {
            for(int j=i+1;j<n;j++) {
                if(arr[i]>arr[j]) {
                    int t=arr[i];
                    arr[i]=arr[j];
                    arr[j]=t;
                }
            }
        }
    }
    int pos=binarySearch(arr,n,rollDigits);
    cout<<"Array: ";
    for(int i=0;i<n;i++) cout<<arr[i]<<" ";
    cout<<endl<<"Position of "<<rollDigits<<": "<<pos;
    return 0;
}
