#include <iostream>
using namespace std;

class Box{
    public:
    int* data;

    Box(int d) {
        data = new int(d);
    }
    Box(const Box& other){
        data = new int(*other.data);
    }
    ~Box(){
        delete data;
    }
    Box& operator +=(int val){
        *data += val;
        return *this;
    }
    void show(){
        cout<<"Value: "<<*data<<endl;
    }
};

int main() {
    Box b1(10);
    cout<<"Original Value: "<<endl;
    b1.show();

    Box b2(0);
    b2 = b1;
    cout<<"\nShallow Copy"<<endl;
    cout<<"B2 copy of B1:\n";
    b2.show();
    b2 += 2;
    cout<<"B2 Value after Changing:\n";
    b2.show();
    cout<<"B1 Value after Changing b2:\n";
    b1.show();

    Box b3 = b1;
    cout<<"\nDeep Copy"<<endl;
    cout<<"B3 copy of B1:\n";
    b3.show();
    b3 += 2;
    cout<<"B3 Value after Changing:\n";
    b3.show();
    cout<<"B1 Value after Changing b3:\n";
    b1.show();

    return 0;
}