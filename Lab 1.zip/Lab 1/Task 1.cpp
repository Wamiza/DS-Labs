#include <iostream>
using namespace std;

class BankAccount{
    public:
    double balance;

    BankAccount(double b){
        balance = b;
    }
    BankAccount(int bal = 1000) {
        balance = bal;
    }
    BankAccount(const BankAccount& other){
        balance = other.balance;
    }
    BankAccount& operator-=(double amount){
    balance-=amount;
    return* this;
    }
    void print() {
        cout<<"Balance: "<<balance<<endl;
    }
};

int main(){
    BankAccount account1(100);
    account1.print();

    BankAccount account2;
    account2.print();

    BankAccount account3 = account2;
    account3 -= 200;
    account3.print();
    account2.print();

    return 0;
}