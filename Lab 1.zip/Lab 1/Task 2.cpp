#include <iostream>
#include <cstring>
using namespace std;

class Exam{
    public:
    char* name;
    int examDate; //DDMMYY
    double score;
    
    Exam(char* n,int ed, double s){
        name = new char[strlen(n)+1];
        strcpy(name,n);
        examDate = ed;
        score =s ;
    }
    ~Exam(){
        delete[] name;
    }

    void details() {
        cout<<"Student Name: "<<name<<endl;
        cout<<"Exam Date: "<<examDate<<endl;
        cout<<"Score: "<<score<<endl;
    }
};

int main(){
    Exam e1("Wamiza",4092025, 86);
    cout<<"Original Data: "<<endl;
    e1.details();
    Exam e2 = e1;
    cout<<"\nCopy Data: "<<endl;
    e2.details();

    return 0;
}